export interface CutPlane {
  id: number;
  nome: string;
  circuitos: number[];
}

export interface CutPlaneWithSegmentId {
  id: number;
  nome: string;
  trechos: [
    {
      id: number;
      identificacaoCabo: string;
    }
  ];
}
