import { FontAwesome } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import { useSync } from "../hooks/useSync";
import Account from "../pages/account";
import Dashboard from "../pages/dashboard";
import StatusApp from "../pages/statusApp";
import InstallRecordStack from "./NotationStack";

export type AppTabParamList = {
  Dashboard: undefined;
  RecordStack: undefined;
  AppStatus: undefined;
  Account: undefined;
};

const Tab = createBottomTabNavigator<AppTabParamList>();

export default function AppTabs() {
  const { hasPending, pendingCount } = useSync();

  return (
    <Tab.Navigator
      initialRouteName="Dashboard"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: "#173e74",
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={Dashboard}
        options={{
          title: "Início",
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="home" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="RecordStack"
        component={InstallRecordStack}
        options={{
          title: "Apontamentos",
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="pencil-square-o" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="AppStatus"
        component={StatusApp}
        options={{
          title: "Status App",
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="cloud" size={size} color={color} />
          ),
          tabBarBadge: hasPending ? pendingCount : undefined,
        }}
      />
      <Tab.Screen
        name="Account"
        component={Account}
        options={{
          title: "Conta",
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="user" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}
