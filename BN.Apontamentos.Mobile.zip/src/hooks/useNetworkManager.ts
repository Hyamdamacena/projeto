import NetInfo from "@react-native-community/netinfo";
import { useEffect, useState } from "react";

export const useNetworkManager = () => {
  const [isConnected, setIsConnected] = useState<boolean | null>(null);
  const [isInternetReachable, setIsInternetReachable] = useState<
    boolean | null
  >(null);
  const [simulateOffline, setSimulateOffline] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      setIsConnected(state.isConnected);
      setIsInternetReachable(state.isInternetReachable);
    });

    return () => unsubscribe();
  }, []);

  const hasConnection = simulateOffline
    ? false
    : isConnected && isInternetReachable;

  return {
    hasConnection,
    setSimulateOffline,
  };
};
