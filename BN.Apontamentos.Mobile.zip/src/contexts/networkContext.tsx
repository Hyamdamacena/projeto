import React, { createContext, ReactNode } from "react";
import { useNetworkManager } from "../hooks/useNetworkManager";

interface NetworkContextData {
  hasConnection: boolean | null;
  setSimulateOffline: React.Dispatch<React.SetStateAction<boolean>>;
}

export const NetworkContext = createContext<NetworkContextData>(
  {} as NetworkContextData
);

interface NetworkProviderProps {
  children: ReactNode;
}

export const NetworkProvider = ({ children }: NetworkProviderProps) => {
  const { hasConnection, setSimulateOffline } = useNetworkManager();

  return (
    <NetworkContext.Provider
      value={{
        hasConnection,
        setSimulateOffline,
      }}
    >
      {children}
    </NetworkContext.Provider>
  );
};
