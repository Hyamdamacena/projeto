import { createContext, ReactNode, useState } from "react";
import { authClient } from "../clients/auth";
import { segmentClient } from "../clients/segment";
import { dataAppStorage, UpdatedAt } from "../services/DataAppStorage";
import { CutPlane } from "../types/cutPlane";
import { Segment } from "../types/segment";

interface DataAppContextType {
  cutPlanes: CutPlane[];
  updatedAt?: UpdatedAt;
  segments: Segment[];
  updateDataApp: (cutPlans: CutPlane[]) => void;
  isLoading: boolean;
}

export const DataAppContext = createContext<DataAppContextType>(
  {} as DataAppContextType
);

interface DataAppProviderProps {
  children: ReactNode;
}

export const DataAppProvider = ({ children }: DataAppProviderProps) => {
  const [cutPlanes, setCutPlanes] = useState<CutPlane[]>([]);
  const [updatedAt, setUpdatedAt] = useState<UpdatedAt>();
  const [segments, setSegments] = useState<Segment[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const syncDataApp = async () => {
    if (isLoading) return;

    setIsLoading(true);
    const cutPlaneStorage = await dataAppStorage.getCutPlane();
    setCutPlanes(cutPlaneStorage);
    const segmentStorage = await dataAppStorage.getSegments();
    setSegments(segmentStorage);
    const dateUpdateAtStorage = await dataAppStorage.getDateUpdatedAt();
    setUpdatedAt({
      label: dateUpdateAtStorage?.label?.replaceAll('"', ""),
      timestamp: dateUpdateAtStorage?.timestamp,
    });
    setIsLoading(false);
  };

  const updateDataApp = async (cutPlans: CutPlane[]) => {
    if (isLoading) return;

    const { token } = await authClient.getToken();
    if (!token) return;

    setIsLoading(true);
    const ids = cutPlans.map((x) => x.id);
    const { data } = await segmentClient.getSegments(ids);
    const segmentsStoage = data ?? [];
    await dataAppStorage.saveDataAppStorage(cutPlans, segmentsStoage);
    setIsLoading(false);

    await syncDataApp();
  };

  const contextValue = {
    cutPlanes,
    updatedAt,
    segments,
    updateDataApp,
    isLoading,
  };

  return (
    <DataAppContext.Provider value={contextValue}>
      {children}
    </DataAppContext.Provider>
  );
};
