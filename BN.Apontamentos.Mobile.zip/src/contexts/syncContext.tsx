import React, { createContext, ReactNode } from "react";
import { useSyncManager } from "../hooks/useSyncManager";

interface SyncContextData {
  isSyncing: boolean;
  pendingCount: number;
  performManualSync: () => Promise<any>;
  hasPending: boolean;
}

export const SyncContext = createContext<SyncContextData>(
  {} as SyncContextData
);

interface SyncProviderProps {
  children: ReactNode;
}

export const SyncProvider = ({ children }: SyncProviderProps) => {
  const { isSyncing, pendingCount, performManualSync } = useSyncManager();

  return (
    <SyncContext.Provider
      value={{
        isSyncing,
        pendingCount,
        performManualSync,
        hasPending: pendingCount > 0,
      }}
    >
      {children}
    </SyncContext.Provider>
  );
};
