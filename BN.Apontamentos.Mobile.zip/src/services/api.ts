import axios from "axios";

const api = axios.create({
  baseURL: "https://bn-apontamentos.tryasp.net",
});

export default api;
