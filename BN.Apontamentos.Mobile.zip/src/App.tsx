import {
  MD3LightTheme as DefaultTheme,
  PaperProvider,
} from "react-native-paper";
import { SafeAreaView } from "react-native-safe-area-context";
import { AuthProvider } from "./contexts/authContext";
import { DataAppProvider } from "./contexts/dataAppContext";
import { NetworkProvider } from "./contexts/networkContext";
import { SyncProvider } from "./contexts/syncContext";
import Navigation from "./navigation";

const theme = {
  ...DefaultTheme,
};

export default () => (
  <SafeAreaView style={{ flex: 1 }}>
    <PaperProvider theme={theme}>
      <NetworkProvider>
        <AuthProvider>
          <SyncProvider>
            <DataAppProvider>
              <Navigation />
            </DataAppProvider>
          </SyncProvider>
        </AuthProvider>
      </NetworkProvider>
    </PaperProvider>
  </SafeAreaView>
);
