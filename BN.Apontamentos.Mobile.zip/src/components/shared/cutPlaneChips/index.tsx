import { ScrollView } from "react-native";
import { Chip } from "react-native-paper";
import { useDataApp } from "../../../hooks/useDataApp";

const CutPlaneChips = () => {
  const { cutPlanes } = useDataApp();
  const Chips = () => (
    <>
      {cutPlanes.map((x) => {
        return (
          <Chip key={x.id} style={{ marginRight: 5 }}>
            {x.nome}
          </Chip>
        );
      })}
    </>
  );

  if (cutPlanes.length == 0) {
    return null;
  }

  return (
    <ScrollView horizontal>
      <Chips />
    </ScrollView>
  );
};

export default CutPlaneChips;
