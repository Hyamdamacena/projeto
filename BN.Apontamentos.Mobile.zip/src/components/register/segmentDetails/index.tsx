import { StyleSheet, View } from "react-native";
import { TextInput } from "react-native-paper";
import { Segment } from "../../../types/segment";

const defaultValues = {
  idTrecho: 0,
  circuito: 0,
  identificacaoCabo: "",
  tagPrevisto: "",
  origem: "",
  destino: "",
  fase: "",
  comprimentoFase: 0,
  comprimentoTodasFases: 0,
  secao: 0,
} as Segment;

interface SegmentDetailsProps {
  information?: Segment;
}

const SegmentDetails = ({
  information = defaultValues,
}: SegmentDetailsProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.column}>
        <TextInput
          label="Circuito"
          value={String(information.circuito)}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Tag Previsto"
          value={information.tagPrevisto}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Origem"
          value={information.origem}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Destino"
          value={information.destino}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
      </View>
      <View style={styles.column}>
        <TextInput
          label="Fase"
          value={information.fase}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Comp. (m)"
          value={String(information.comprimentoFase)}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Comp. 3F (m)"
          value={String(information.comprimentoTodasFases)}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
        <TextInput
          label="Seção (mm²)"
          value={String(information.secao)}
          editable={false}
          mode="outlined"
          style={styles.input}
        />
      </View>
    </View>
  );
};

export default SegmentDetails;

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    justifyContent: "space-between",
    marginVertical: 10,
  },
  column: {
    flex: 1,
    minWidth: "48%",
    gap: 10,
  },
  input: {
    backgroundColor: "transparent",
  },
});
