import { useEffect, useState } from "react";
import { StyleSheet, View } from "react-native";
import { Button } from "react-native-paper";
import { Dropdown } from "react-native-paper-dropdown";
import { useDataApp } from "../../../hooks/useDataApp";

interface Options {
  label: string;
  value: string;
}

interface DropdownViewProps {
  planeValueSelected: string;
  onSelectPlane: (value?: string) => void;
  segmentValueSelected: string;
  onSelectSegment: (value?: string) => void;
  onClearSelection: () => void;
}

const DropdownView = ({
  planeValueSelected,
  onSelectPlane,
  segmentValueSelected,
  onSelectSegment: onSelectCable,
  onClearSelection,
}: DropdownViewProps) => {
  const [planeOptions, setPlaneOptions] = useState<Options[]>([]);
  const [cableIdentifications, setCableIdentifications] = useState<Options[]>(
    []
  );
  const { cutPlanes, segments } = useDataApp();
  const bothSelected =
    planeValueSelected.length > 0 && segmentValueSelected.length > 0;

  const handleChangePlaneId = (value?: string) => {
    onSelectPlane(value);

    if (segments.length === 0) {
      return;
    }

    const cablesOption = segments
      .filter((segment) => segment.idPlanoDeCorte.toString() === value)
      .map((segment) => {
        return {
          label: segment.identificacaoCabo,
          value: segment.idTrecho.toString(),
        };
      });
    setCableIdentifications(cablesOption);
  };

  const handleClearBoth = () => {
    onSelectPlane("");
    onSelectCable("");
    onClearSelection();
  };

  useEffect(() => {
    if (cutPlanes.length > 0) {
      setPlaneOptions(
        cutPlanes.map((p) => {
          return { label: p.nome, value: p.id.toString() };
        })
      );
    }
  }, [cutPlanes]);

  return (
    <View style={styles.container}>
      <Dropdown
        disabled={planeOptions.length === 0 || bothSelected}
        label={"Plano de Corte"}
        placeholder="Selecione"
        options={planeOptions}
        value={planeValueSelected}
        onSelect={handleChangePlaneId}
        mode="outlined"
      />
      <Dropdown
        disabled={cableIdentifications.length === 0 || bothSelected}
        label={"Trecho"}
        placeholder="Selecione"
        options={cableIdentifications}
        value={segmentValueSelected}
        onSelect={onSelectCable}
        mode="outlined"
      />
      <Button
        disabled={!bothSelected}
        mode="contained"
        onPress={handleClearBoth}
        style={styles.button}
      >
        Limpar seleção
      </Button>
    </View>
  );
};

export default DropdownView;

const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
    gap: 10,
  },
  button: {
    marginTop: 10,
  },
});
