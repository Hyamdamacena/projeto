import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { StyleSheet, View } from "react-native";
import { Button, Chip, Divider, Switch, Text } from "react-native-paper";
import { IconSource } from "react-native-paper/lib/typescript/components/Icon";
import { useDataApp } from "../../hooks/useDataApp";
import { useNetwork } from "../../hooks/useNetwork";
import { useSync } from "../../hooks/useSync";

const StatusApp = () => {
  const [simulate, setSimulate] = useState(false);
  const { pendingCount, hasPending, performManualSync, isSyncing } = useSync();
  const { cutPlanes } = useDataApp();
  const { hasConnection, setSimulateOffline } = useNetwork();

  const onToggleSwitch = () => {
    setSimulate((prev) => !prev);
    setSimulateOffline((prev) => !prev);
  };

  const IconWifi: IconSource = (props) => (
    <MaterialIcons
      name={hasConnection ? "wifi" : "wifi-off"}
      size={props.size}
      color={props.color}
    />
  );

  const IconPending: IconSource = (props) => (
    <MaterialIcons
      name={hasPending ? "radio-button-unchecked" : "check-circle-outline"}
      size={props.size}
      color={props.color}
    />
  );

  const IconSync: IconSource = (props) => (
    <MaterialIcons name="sync" size={props.size} color={props.color} />
  );

  return (
    <View style={styles.main}>
      <Text variant="headlineLarge" style={styles.titles}>
        Status dos Apontamentos
      </Text>
      <Text variant="titleSmall" style={styles.titles}>
        Acompanhe o status dos apontamentos
      </Text>
      <Divider style={{ marginBottom: 10 }} />
      <View style={styles.lineBetween}>
        <Text variant="bodyLarge">Conexão com internet</Text>
        <Chip icon={IconWifi}>{hasConnection ? "online" : "offline"}</Chip>
      </View>
      <View style={styles.lineBetween}>
        <Text variant="bodyLarge">Itens pendentes de sincronização</Text>
        <Chip icon={IconPending}>{pendingCount}</Chip>
      </View>
      {hasPending && hasConnection && (
        <>
          <View style={styles.lineBetween}>
            <Text variant="bodyLarge">Sincronizar agora</Text>
            <Button
              mode="contained"
              compact
              onPress={() => performManualSync()}
              loading={isSyncing}
              icon={IconSync}
            >
              Enviar
            </Button>
          </View>
          <Divider />
        </>
      )}
      <View style={styles.lineBetween}>
        <Text variant="bodyLarge">Planos de corte carregados</Text>
        <Chip>{cutPlanes.length}</Chip>
      </View>
      <Divider />
      <View style={styles.lineBetween}>
        <Text variant="bodyLarge">Simular cenário offline</Text>
        <Switch value={simulate} onValueChange={onToggleSwitch} />
      </View>
    </View>
  );
};

export default StatusApp;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingHorizontal: 10,
    paddingTop: 30,
    paddingBottom: 10,
  },
  titles: {
    marginBottom: 10,
  },
  lineBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 5,
    paddingVertical: 5,
  },
});
