import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import { Divider, Snackbar, Text } from "react-native-paper";
import { notationClient } from "../../clients/installRecord";
import DropdownView from "../../components/register/dropdowView";
import NetStatus from "../../components/register/netStatus";
import RecordForm, {
  RecordFormSubmitData,
} from "../../components/register/recordForm";
import SegmentDetails from "../../components/register/segmentDetails";
import { useAuth } from "../../hooks/useAuth";
import { useDataApp } from "../../hooks/useDataApp";
import { useNetwork } from "../../hooks/useNetwork";
import { InstallRecordSubmit } from "../../types/installRecord";
import { Segment } from "../../types/segment";

export default function Register() {
  const [isLoading, setIsLoading] = useState(false);
  const [planeIdSelected, setPlaneIdSelected] = useState("");
  const [segmentIdSelected, setSegmentIdSelected] = useState("");
  const [segmentInfo, setSegmentInfo] = useState<Segment>();
  const [showSnack, setShowSnack] = useState({
    open: false,
    message: "",
    type: "success" as "success" | "error" | "warning",
  });

  const { user, setStatus } = useAuth();
  const { segments } = useDataApp();
  const { hasConnection } = useNetwork();

  const handleSelectPlane = (value: any) => {
    setPlaneIdSelected(value);
  };

  const handleSelectSegment = (value: any) => {
    setSegmentIdSelected(value);
    const segment = segments.find((x) => x.idTrecho.toString() === value);
    setSegmentInfo(segment);
  };

  const bothSelected =
    planeIdSelected.length === 0 ||
    segmentIdSelected.length === 0 ||
    !segmentInfo;

  const handleClearBoth = () => {
    setPlaneIdSelected("");
    setSegmentIdSelected("");
    setSegmentInfo(undefined);
  };

  const handleSimulateOffLine = async (request: InstallRecordSubmit) => {
    if (isLoading) return;

    setIsLoading(true);
    const { error, savedOffline } = await notationClient.createOffLine(request);
    setIsLoading(false);
    if (savedOffline) {
      setShowSnack({
        open: true,
        message: error!,
        type: "warning",
      });
    } else {
      setShowSnack({ open: true, message: error!, type: "error" });
    }
    handleClearBoth();

    return;
  };

  const handleSubmit = async (data: RecordFormSubmitData) => {
    if (isLoading) return;

    const request = {
      idTrecho: Number(segmentIdSelected),
      matriculaUsuario: Number(user?.matricula),
      tagReal: data.tagReal,
      metragemInicio: data.metragemInicio,
      metragemFim: data.metragemFim,
      observacao: data.observacao?.trim(),
      dataLancamento: data.dataLancamento,
    };

    if (!hasConnection) {
      return handleSimulateOffLine(request);
    }

    setIsLoading(true);
    const { error, status, savedOffline } = await notationClient.create(
      request
    );
    setIsLoading(false);

    if (status === 401) {
      setStatus("unauth");
      return;
    } else if (error) {
      if (savedOffline) {
        setShowSnack({
          open: true,
          message: error,
          type: "warning",
        });
        handleClearBoth();
      } else {
        setShowSnack({ open: true, message: error, type: "error" });
      }
      return;
    }

    setShowSnack({
      open: true,
      message: "Registro efetuado com sucesso.",
      type: "success",
    });
    handleClearBoth();
  };

  const onDismissSnackBar = () => {
    setShowSnack((prev) => {
      return { ...prev, open: false };
    });
  };

  useFocusEffect(
    useCallback(() => {
      return () => handleClearBoth();
    }, [])
  );

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.main}
    >
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Text variant="headlineSmall">Registrar novo Apontamento</Text>
            <NetStatus />
          </View>
          <DropdownView
            segmentValueSelected={segmentIdSelected}
            planeValueSelected={planeIdSelected}
            onSelectSegment={handleSelectSegment}
            onSelectPlane={handleSelectPlane}
            onClearSelection={() => setSegmentInfo(undefined)}
          />
          <Divider style={styles.divider} />
          <Text variant="titleMedium" style={{ marginTop: 10 }}>
            Preenchimento automático
          </Text>
          <SegmentDetails information={segmentInfo} />
          <Divider style={styles.divider} />
          <Text variant="titleMedium" style={{ marginTop: 10 }}>
            Preenchimento manual
          </Text>
          <RecordForm
            isLoading={isLoading}
            submit={handleSubmit}
            isDisabled={bothSelected}
          />
          <Snackbar
            visible={showSnack.open}
            onDismiss={onDismissSnackBar}
            action={{
              label: "Fechar",
              onPress: onDismissSnackBar,
            }}
            style={[
              styles.snackbar,
              showSnack.type === "error" && styles.errorSnackbar,
              showSnack.type === "warning" && styles.warningSnackbar,
            ]}
          >
            {showSnack.message}
          </Snackbar>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingHorizontal: 10,
    paddingTop: 10,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  divider: {
    marginVertical: 10,
  },
  snackbar: {
    backgroundColor: "#4caf50",
  },
  errorSnackbar: {
    backgroundColor: "#f44336",
  },
  warningSnackbar: {
    backgroundColor: "#ff9800",
  },
});
