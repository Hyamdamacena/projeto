import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { StyleSheet, View } from "react-native";
import { Avatar, Button, Text } from "react-native-paper";
import { IconSource } from "react-native-paper/lib/typescript/components/Icon";
import { authClient } from "../../clients/auth";
import { useAuth } from "../../hooks/useAuth";

export default function Account() {
  const { user, setStatus } = useAuth();

  const handleSignOut = async () => {
    await authClient.signOut();
    setStatus("unauth");
  };

  const Icon: IconSource = (props) => (
    <MaterialIcons
      name="account-circle"
      size={props.size}
      color={props.color}
    />
  );

  return (
    <View style={styles.container}>
      <Avatar.Icon size={80} icon={Icon} />
      <Text variant="headlineLarge" style={{ marginTop: 15 }}>
        {user?.nome}
      </Text>
      <Text variant="titleMedium" style={{ marginTop: 5 }}>
        {user?.matricula}
      </Text>
      <Button
        mode="contained"
        onPress={handleSignOut}
        style={{ marginTop: 20 }}
      >
        Sair
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center" },
});
