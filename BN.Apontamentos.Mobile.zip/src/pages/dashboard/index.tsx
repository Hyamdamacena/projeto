import { useEffect, useState } from "react";
import { Image, ImageBackground, StyleSheet, View } from "react-native";
import { Button, Modal, Text } from "react-native-paper";
import { MultiSelectDropdown, Option } from "react-native-paper-dropdown";
import { cutClient } from "../../clients/cutPlane";
import CutPlaneChips from "../../components/shared/cutPlaneChips";
import { useAuth } from "../../hooks/useAuth";
import { useDataApp } from "../../hooks/useDataApp";
import { CutPlane } from "../../types/cutPlane";

export default function Dashboard() {
  const [showModal, setShowModal] = useState(false);
  const [cutPlanes, setCutPlanes] = useState<CutPlane[]>([]);
  const [dropdownOptions, setDropdownOptions] = useState<Option[]>([]);
  const [optionsSelected, setOptionsSelected] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { updatedAt, updateDataApp } = useDataApp();
  const { setStatus } = useAuth();

  const cutPlaneOld = updatedAt?.timestamp
    ? new Date(updatedAt.timestamp).setHours(0, 0, 0, 0) <
      new Date().setHours(0, 0, 0, 0)
    : true;

  const getCutPlanes = async () => {
    setIsLoading(true);
    const { data, status } = await cutClient.getAll();
    setIsLoading(false);

    if (data) {
      setCutPlanes(data);
      setDropdownOptions(
        data.map((x) => {
          return { label: x.nome, value: x.id.toString() };
        })
      );
      if (cutPlaneOld) setShowModal(true);

      return;
    }
    if (status === 401) {
      setStatus("unauth");
      return;
    }
  };

  const handleUpdateCutPlanes = () => {
    setShowModal(false);
    if (optionsSelected.length === 0) return;

    setIsLoading(true);
    const cutPlanesToStorage = cutPlanes.filter((x) =>
      optionsSelected.includes(x.id.toString())
    );
    updateDataApp(cutPlanesToStorage);
    setIsLoading(false);
  };

  const handleCutPlane = (values: string[]) => {
    setOptionsSelected(values);
  };

  const handleNewLoading = async () => {
    await getCutPlanes();
    setShowModal(true);
  };

  useEffect(() => {
    getCutPlanes();
  }, []);

  return (
    <ImageBackground
      source={require("../../assets/background.jpg")}
      style={styles.background}
    >
      <View style={styles.container}>
        <View style={styles.containerImg}>
          <Image style={styles.img} source={require("../../assets/logo.png")} />
        </View>
        <View style={styles.banner}>
          <Text variant="titleLarge" onPress={() => setShowModal(true)}>
            Última carga de Planos de Corte
          </Text>
          <Text
            variant="bodyLarge"
            style={{ color: cutPlaneOld ? "red" : undefined }}
          >
            {updatedAt && updatedAt.label
              ? updatedAt.label
              : "Nenhum plano de corte carregado"}
          </Text>
          <CutPlaneChips />
          <Button
            disabled={cutPlanes.length === 0 || isLoading}
            loading={isLoading}
            mode="contained"
            onPress={handleNewLoading}
          >
            Nova Carga
          </Button>
        </View>
        <Modal
          visible={showModal}
          onDismiss={() => setShowModal(false)}
          contentContainerStyle={styles.modal}
        >
          <Text variant="titleLarge">Planos de Corte a carregar</Text>
          <MultiSelectDropdown
            label="Selecionar"
            options={dropdownOptions}
            value={optionsSelected}
            onSelect={handleCutPlane}
            mode="outlined"
            disabled={isLoading}
          />
          <Button mode="contained" onPress={handleUpdateCutPlanes}>
            Ok
          </Button>
        </Modal>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1,
    backgroundColor: "rgba(255,255,255,0.7)",
    zIndex: 1,
  },
  containerImg: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  img: { width: "45%", maxHeight: 75, resizeMode: "contain" },
  banner: {
    backgroundColor: "rgb(255,255,255)",
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
    padding: 10,
    gap: 10,
  },
  modal: {
    borderRadius: 15,
    margin: 20,
    backgroundColor: "white",
    padding: 20,
    gap: 20,
  },
});
