import { zodResolver } from "@hookform/resolvers/zod";
import React, { useState } from "react";
import { Controller, useForm } from "react-hook-form";
import {
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import { Button, Snackbar, Text, TextInput } from "react-native-paper";
import { z as zod } from "zod";
import { authClient } from "../../clients/auth";
import { useAuth } from "../../hooks/useAuth";

const signInSchema = zod.object({
  matricula: zod
    .string()
    .min(1, "Informe a matricula")
    .regex(/^\d{8}$/, "A matrícula deve conter 8 números"),
  senha: zod.string().min(1, "A senha é obrigatória"),
});

type SignInSchema = zod.infer<typeof signInSchema>;

export default function SignIn() {
  const { setStatus, checkAuthStatus } = useAuth();
  const [showSnack, setShowSnack] = useState(false);
  const [rootError, setRootError] = useState("");

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<SignInSchema>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      matricula: "",
      senha: "",
    },
  });

  const onSubmit = async (data: SignInSchema) => {
    Keyboard.dismiss;
    const { user, error } = await authClient.signInWithPassword(data);
    setRootError("");

    if (user) {
      checkAuthStatus?.();
      setStatus("auth");
      return;
    }

    setRootError(error ? error : "Tente novamente");
  };

  const Form = () => (
    <View style={styles.form}>
      <Text variant="displaySmall">Entrar</Text>
      <Text variant="titleLarge">Informe matricula e senha para entrar</Text>
      <Controller
        control={control}
        name="matricula"
        render={({ field: { onChange, onBlur, value } }) => (
          <>
            <TextInput
              label="Matrícula"
              value={value}
              onChangeText={(text) => onChange(text.replace(/[^0-9]/g, ""))}
              onBlur={onBlur}
              keyboardType="numeric"
              style={{ marginTop: 20 }}
              mode="outlined"
            />
            {errors.matricula && (
              <Text style={{ color: "red" }}>{errors.matricula.message}</Text>
            )}
          </>
        )}
      />
      <Controller
        control={control}
        name="senha"
        render={({ field: { onChange, onBlur, value } }) => (
          <>
            <TextInput
              label="Senha"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              secureTextEntry
              style={{ marginTop: 5 }}
              mode="outlined"
            />
            {errors.senha && (
              <Text style={{ color: "red" }}>{errors.senha.message}</Text>
            )}
          </>
        )}
      />
      <Button
        compact
        mode="contained"
        onPress={handleSubmit(onSubmit)}
        loading={isSubmitting}
        disabled={isSubmitting}
        style={{ marginTop: 20 }}
      >
        Entrar
      </Button>
      {rootError.length > 0 && <Text variant="titleMedium">{rootError}</Text>}
      <View style={styles.signUp}>
        <Text variant="titleMedium">Se não tem acesso, solicite </Text>
        <Button
          compact
          mode="text"
          labelStyle={styles.signUpButton}
          onPress={() => setShowSnack(true)}
        >
          Aqui
        </Button>
      </View>
    </View>
  );

  const MUISnackbar = () => (
    <Snackbar
      duration={2000}
      visible={showSnack}
      onDismiss={() => setShowSnack(false)}
      action={{
        label: "Fechar",
        onPress: () => setShowSnack(false),
      }}
      style={styles.warningSnackbar}
    >
      Ainda em implementação.
    </Snackbar>
  );

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.main}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.container}>
          <View style={styles.containerImg}>
            <Image
              source={require("../../../assets/splash-icon.png")}
              style={styles.img}
            />
          </View>
          <Form />
          <MUISnackbar />
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  containerImg: {
    padding: 20,
    maxHeight: 50,
    alignItems: "flex-end",
  },
  img: {
    width: "15%",
    maxHeight: 30,
    resizeMode: "contain",
  },
  form: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
    gap: 10,
  },
  signUp: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  signUpButton: {
    fontSize: 16,
    fontWeight: "500",
    letterSpacing: 0.15,
    lineHeight: 24,
  },
  warningSnackbar: {
    backgroundColor: "#ff9800",
  },
});
