import { MaterialIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { Button, Snackbar, Text } from "react-native-paper";
import { IconSource } from "react-native-paper/lib/typescript/components/Icon";
import { notationClient } from "../../clients/installRecord";
import NoteTable from "../../components/installRecord/noteTable";
import { useAuth } from "../../hooks/useAuth";
import { InstallRecord } from "../../types/installRecord";

export default function RecordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [notations, setNotations] = useState<InstallRecord[]>([]);
  const [showSnack, setShowSnack] = useState({
    open: false,
    message: "",
  });
  const { setStatus } = useAuth();
  const navigation = useNavigation();

  const handleUpdate = async () => {
    if (isLoading) return;
    setIsLoading(true);
    setNotations([]);
    const { data, error, status } = await notationClient.getAll(1, 100);

    if (status === 401) {
      setStatus("unauth");
      return;
    } else if (data) {
      setNotations(data.registros);
    } else if (error) {
      setShowSnack({ open: true, message: error });
    }

    setIsLoading(false);
  };

  const onDismissSnackBar = () => {
    setShowSnack((prev) => {
      return { ...prev, open: false };
    });
  };

  const handleRegister = () =>
    navigation.navigate("App", {
      screen: "RecordStack",
      params: {
        screen: "Register",
      },
    });

  const IconFilter: IconSource = (props) => (
    <MaterialIcons name="filter-alt" size={props.size} color={props.color} />
  );

  const IconUpdate: IconSource = (props) => (
    <MaterialIcons name="update" size={props.size} color={props.color} />
  );

  const IconAdd: IconSource = (props) => (
    <MaterialIcons name="add-box" size={props.size} color={props.color} />
  );

  return (
    <View style={styles.main}>
      <Text variant="headlineLarge">Painel de Apontamentos</Text>
      <Text variant="titleSmall" style={{ marginTop: 10 }}>
        Acompanhe os apontamentos já registrados
      </Text>
      <View
        style={{
          flexDirection: "row",
          gap: 10,
          marginVertical: 10,
          paddingVertical: 5,
        }}
      >
        <Button icon={IconFilter} mode="contained" disabled>
          Filtrar
        </Button>
        <Button
          icon={IconUpdate}
          mode="contained"
          onPress={handleUpdate}
          loading={isLoading}
        >
          Atualizar
        </Button>
      </View>
      <ScrollView horizontal>
        <NoteTable notations={notations} />
      </ScrollView>
      <Button
        icon={IconAdd}
        mode="contained"
        onPress={handleRegister}
        style={{ marginTop: 10 }}
      >
        Registrar
      </Button>
      <Snackbar
        visible={showSnack.open}
        onDismiss={onDismissSnackBar}
        action={{
          label: "Fechar",
          onPress: onDismissSnackBar,
        }}
      >
        {showSnack.message}
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingHorizontal: 10,
    paddingTop: 30,
    paddingBottom: 10,
  },
});
